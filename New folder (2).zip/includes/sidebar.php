<style type="text/css">
  .selectedop:hover{
  transform: scale(1.2);
  transition-duration: 0.2s;
}
  .selectedop{
  transform: scale(1);
  transition-duration: 0.5s ;
}
</style>

<div id="sidebar">
      <ul class="nav">
        <li><a class="headitem item1" href="">Dashboard</a>
          <ul class="opened">
            <li class="selectedop"><a href="editoriales.php">Editoriales</a>
        </li>
        <li class="selectedop"><a href="libros.php">Libros</a>
        </li>
        <li class="selectedop"><a href="autores.php">Autores</a>
        </li>
        <li class="selectedop"><a href="tipoRecurso.php">Tipo de recurso</a>
        </li>


        <li class="selectedop"><a href="reservas.php">Reservas pendientes</a></li>
        <li class="selectedop"><a href="reservaciones.php">Reservas aprobadas</a></li>


        <li class="selectedop"><a href="hacerPrestamo.php">Nuevo Prestamo</a></li>
        <li class="selectedop"><a href="personas.php">Personas</a></li>
        <li class="selectedop"><a href="consultaPrestamos.php">Ver Prestamos</a></li>


        <li class="selectedop"><a href="ajustes.php">Ajustes</a></li>
        <li class="selectedop"><a href="MantUsuario.php">Usuarios</a></li>
          </ul>
        </li>


        <li><a class="headitem item2" href="">Reportes</a>
          <ul>
             <li class="selectedop"><a href="reportes.php">Reportes</a></li>
          </ul>
        
        </li>


        <li><a class="headitem item3" href="">Respaldo</a>
            <ul>
             <li class="selectedop"><a href="download.php">Descargar copia</a></li>
          </ul>   
        </li>
          </ul>
</div>