 <META http-equiv="refresh" content="0;URL=../index.php?">
 <?php
exit;
?>
