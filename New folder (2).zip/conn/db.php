<?php
//adcow - Administrador de Contenido Web.
//Programación Alternativa
//Ing. Guillermo Mora Granados

//CONFIGURACIÓN BÁSICA SITIO WEB

$server = 'localhost'; //remplace por la dirección del servidor
$user = 'a5893777t'; //remplace por el usuario de la base de datos
$password = 'codeMars WEB97'; //remplace por la contraseña de la base de datos
$database = 'a5893777_progra3'; //remplace por el nombre de la base de datos

$base_url = 'http://localhost/biblioteca/'; //remplace por la direccion base del sitio web

?>
