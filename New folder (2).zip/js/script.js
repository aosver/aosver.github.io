jQuery(document).ready(function(){
	
	jQuery('input[type=checkbox]').tzCheckbox({labels:['Enable','Disable']});
});